import type { GameState } from './game-types'
import type { UIMessage } from 'ai'

export interface SaveData {
  version: number
  savedAt: string
  gameState: GameState
  messages: SerializedMessage[]
}

export interface SerializedMessage {
  id: string
  role: 'user' | 'assistant'
  parts: { type: 'text'; text: string }[]
}

const SAVE_VERSION = 1

/**
 * UIMessage 배열을 직렬화 (저장용)
 */
function serializeMessages(messages: UIMessage[]): SerializedMessage[] {
  return messages.map((msg) => ({
    id: msg.id,
    role: msg.role as 'user' | 'assistant',
    parts: (msg.parts ?? [])
      .filter((p): p is { type: 'text'; text: string } => p.type === 'text')
      .map((p) => ({ type: 'text' as const, text: p.text })),
  }))
}

/**
 * 직렬화된 메시지를 UIMessage 형태로 복원
 */
export function deserializeMessages(msgs: SerializedMessage[]): UIMessage[] {
  return msgs.map((msg) => ({
    id: msg.id,
    role: msg.role,
    parts: msg.parts,
    content: msg.parts.map((p) => p.text).join(''),
    createdAt: new Date(),
  })) as UIMessage[]
}

/**
 * 게임 상태 + 메시지를 Base64 코드로 직렬화
 */
export function createSaveCode(gameState: GameState, messages: UIMessage[]): string {
  const saveData: SaveData = {
    version: SAVE_VERSION,
    savedAt: new Date().toISOString(),
    gameState,
    messages: serializeMessages(messages),
  }

  const json = JSON.stringify(saveData)
  // btoa는 ASCII만 처리하므로 UTF-8 → Base64 변환
  const encoded = btoa(
    encodeURIComponent(json).replace(/%([0-9A-F]{2})/g, (_match, p1) =>
      String.fromCharCode(parseInt(p1, 16))
    )
  )

  // 가독성을 위해 40자마다 '-' 구분자 삽입
  return encoded.replace(/(.{40})/g, '$1-').replace(/-$/, '')
}

/**
 * Base64 코드를 게임 상태 + 메시지로 역직렬화
 */
export function loadFromCode(code: string): SaveData | null {
  try {
    // 구분자 제거
    const cleaned = code.replace(/-/g, '').trim()
    const json = decodeURIComponent(
      Array.from(atob(cleaned))
        .map((c) => '%' + c.charCodeAt(0).toString(16).padStart(2, '0'))
        .join('')
    )
    const data = JSON.parse(json) as SaveData

    if (!data.version || !data.gameState || !Array.isArray(data.messages)) {
      return null
    }

    return data
  } catch {
    return null
  }
}
