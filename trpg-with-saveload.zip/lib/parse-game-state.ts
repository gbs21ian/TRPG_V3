import type { GameState } from './game-types'

export function parseGameStateFromMessage(text: string): Partial<GameState> | null {
  const match = text.match(/\[GAME_STATE\]\s*([\s\S]*?)\s*\[\/GAME_STATE\]/)
  if (!match) return null

  try {
    const jsonStr = match[1].replace(/```json?\s*/g, '').replace(/```/g, '').trim()
    return JSON.parse(jsonStr)
  } catch {
    return null
  }
}

export function stripGameState(text: string): string {
  return text.replace(/\[GAME_STATE\][\s\S]*?\[\/GAME_STATE\]/g, '').trim()
}

export interface ParsedHUD {
  hp: number
  maxHp: number
  sanity: number
  maxSanity: number
  alignment: number
  alignmentLabel: string
  fame: number
  level: number
  location: string
  statusEffects: string[]
}

export function parseHUDFromMessage(text: string): ParsedHUD | null {
  const hudMatch = text.match(/\[HUD\]([\s\S]*?)\[\/HUD\]/)
  if (!hudMatch) {
    const altMatch = text.match(/HP:\s*(\d+)\s*\/\s*(\d+)/)
    if (!altMatch) return null

    const hp = parseInt(altMatch[1])
    const maxHp = parseInt(altMatch[2])
    const sanityMatch = text.match(/정신력:\s*(\d+)\s*\/\s*(\d+)/)
    const alignmentMatch = text.match(/정렬:\s*(-?\d+)\s*\(([^)]+)\)/)
    const fameMatch = text.match(/명성:\s*(\d+)/)
    const levelMatch = text.match(/Lv\.(\d+)/)
    const locationMatch = text.match(/(?:장소|📍)[:\s]*(.+?)(?:\n|$)/)

    return {
      hp,
      maxHp,
      sanity: sanityMatch ? parseInt(sanityMatch[1]) : 50,
      maxSanity: sanityMatch ? parseInt(sanityMatch[2]) : 50,
      alignment: alignmentMatch ? parseInt(alignmentMatch[1]) : 0,
      alignmentLabel: alignmentMatch ? alignmentMatch[2] : '중립',
      fame: fameMatch ? parseInt(fameMatch[1]) : 0,
      level: levelMatch ? parseInt(levelMatch[1]) : 1,
      location: locationMatch ? locationMatch[1].trim() : '',
      statusEffects: [],
    }
  }

  const hudText = hudMatch[1]
  const hpMatch = hudText.match(/HP:\s*(\d+)\s*\/\s*(\d+)/)
  const sanityMatch = hudText.match(/정신력:\s*(\d+)\s*\/\s*(\d+)/)
  const alignmentMatch = hudText.match(/정렬:\s*(-?\d+)\s*\(([^)]+)\)/)
  const fameMatch = hudText.match(/명성:\s*(\d+)/)
  const levelMatch = hudText.match(/Lv\.(\d+)/)
  const locationMatch = hudText.match(/장소:\s*(.+?)(?:\n|$)/)

  if (!hpMatch) return null

  return {
    hp: parseInt(hpMatch[1]),
    maxHp: parseInt(hpMatch[2]),
    sanity: sanityMatch ? parseInt(sanityMatch[1]) : 50,
    maxSanity: sanityMatch ? parseInt(sanityMatch[2]) : 50,
    alignment: alignmentMatch ? parseInt(alignmentMatch[1]) : 0,
    alignmentLabel: alignmentMatch ? alignmentMatch[2] : '중립',
    fame: fameMatch ? parseInt(fameMatch[1]) : 0,
    level: levelMatch ? parseInt(levelMatch[1]) : 1,
    location: locationMatch ? locationMatch[1].trim() : '',
    statusEffects: [],
  }
}

export function parseRollLog(text: string): string | null {
  const match = text.match(/\[ROLL LOG\]([\s\S]*?)\[\/ROLL LOG\]/)
  return match ? match[1].trim() : null
}
