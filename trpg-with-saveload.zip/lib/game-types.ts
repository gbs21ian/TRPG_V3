export interface GameState {
  phase: 'world-setup' | 'race-roll' | 'stat-roll' | 'player-input' | 'skill-gen' | 'playing'
  character: CharacterSheet | null
  world: WorldSetting | null
  quests: Quest[]
  npcs: NPCRelation[]
  factions: FactionLoyalty[]
  campaignProgress: number
  day: number
  timeOfDay: 'morning' | 'afternoon' | 'evening' | 'night'
  nationUnlocked: boolean
  nationStats: NationStats | null
}

export interface CharacterSheet {
  name: string
  race: string
  class: string
  level: number
  exp: number
  stats: {
    strength: number
    agility: number
    intelligence: number
    charisma: number
    endurance: number
    luck: number
  }
  hp: number
  maxHp: number
  sanity: number
  maxSanity: number
  alignment: number
  fame: number
  gold: number
  skills: Skill[]
  inventory: InventoryItem[]
  equipment: {
    weapon: EquipmentItem | null
    armor: EquipmentItem | null
    accessory: EquipmentItem | null
  }
  statusEffects: StatusEffect[]
  corruptionValue?: number
  backstory?: string
  personality?: string
  narrativeStrength?: string
  narrativeWeakness?: string
}

export interface Skill {
  name: string
  type: 'active' | 'passive' | 'conditional'
  stat: string
  effect: string
  failRisk: string
  cooldown: number
  currentCooldown: number
}

export interface InventoryItem {
  name: string
  quantity: number
  effect?: string
}

export interface EquipmentItem {
  name: string
  grade: 'common' | 'rare' | 'heroic' | 'legendary'
  bonus: number
  effect?: string
}

export interface StatusEffect {
  name: string
  icon: string
  turnsRemaining: number
  effect: string
}

export interface WorldSetting {
  name: string
  civilizationLevel: string
  tone: string
  mainConflict: string
  geography: string
  factions: Faction[]
}

export interface Faction {
  name: string
  goal: string
  alignment: string
  base: string
  playerAttitude: 'friendly' | 'neutral' | 'hostile'
  notes: string
}

export interface Quest {
  name: string
  type: 'main' | 'sub' | 'hidden' | 'personal'
  client: string
  objective: string
  reward: string
  progressContribution: number
  status: 'active' | 'completed' | 'failed'
}

export interface NPCRelation {
  name: string
  role: string
  faction: string
  affinity: number
  status: 'unknown' | 'acquaintance' | 'friendly' | 'trusted' | 'hostile' | 'grudge' | 'dead'
  secret?: string
  notes: string
}

export interface FactionLoyalty {
  name: string
  loyalty: number
  status: 'alliance' | 'friendly' | 'neutral' | 'hostile' | 'war'
}

export interface NationStats {
  military: number
  economy: number
  security: number
  diplomacy: number
}

export function getAlignmentLabel(alignment: number): string {
  if (alignment >= 60) return '영웅'
  if (alignment >= 20) return '선량'
  if (alignment >= -19) return '중립'
  if (alignment >= -59) return '악'
  return '폭군'
}

export function getStatModifier(stat: number): number {
  return Math.floor((stat - 10) / 2)
}

export function calculateHP(endurance: number): number {
  return Math.min(90, Math.max(15, endurance * 5))
}

export function calculateSanity(intelligence: number): number {
  return 50 + getStatModifier(intelligence) * 5
}

export const LEVEL_EXP_TABLE: Record<number, number> = {
  1: 0,
  2: 100,
  3: 250,
  4: 500,
  5: 900,
  6: 1400,
  7: 2000,
  8: 2800,
  9: 3800,
  10: 5000,
}

export const RACES = [
  '인간', '엘프', '드워프', '수인', '드래곤킨',
  '뱀파이어', '서큐버스', '천사', '악마', '사이렌', '드루이드',
] as const

export const initialGameState: GameState = {
  phase: 'world-setup',
  character: null,
  world: null,
  quests: [],
  npcs: [],
  factions: [],
  campaignProgress: 0,
  day: 1,
  timeOfDay: 'morning',
  nationUnlocked: false,
  nationStats: null,
}
