import { TRPGGame } from '@/components/trpg-game'

export default function Page() {
  return <TRPGGame />
}
