'use client'

import { Heart, Brain, Scale, Star, Shield } from 'lucide-react'
import type { ParsedHUD } from '@/lib/parse-game-state'

function StatBar({
  icon: Icon,
  label,
  current,
  max,
  colorClass,
}: {
  icon: React.ElementType
  label: string
  current: number
  max: number
  colorClass: string
}) {
  const pct = Math.max(0, Math.min(100, (current / max) * 100))
  return (
    <div className="flex items-center gap-2">
      <Icon className={`size-4 shrink-0 ${colorClass}`} />
      <span className="text-xs font-mono text-muted-foreground w-12 shrink-0">{label}</span>
      <div className="flex-1 h-2 bg-secondary rounded-full overflow-hidden">
        <div
          className={`h-full rounded-full transition-all duration-500 ${colorClass.replace('text-', 'bg-')}`}
          style={{ width: `${pct}%` }}
        />
      </div>
      <span className="text-xs font-mono text-foreground w-16 text-right shrink-0">
        {current}/{max}
      </span>
    </div>
  )
}

export function GameHUD({ hud }: { hud: ParsedHUD | null }) {
  if (!hud) {
    return (
      <div className="flex items-center justify-center py-4 px-4 border-b border-border bg-card/50">
        <p className="text-sm text-muted-foreground font-mono">
          게임 시작을 기다리는 중...
        </p>
      </div>
    )
  }

  return (
    <div className="border-b border-border bg-card/80 backdrop-blur-sm">
      <div className="px-4 py-3 flex flex-col gap-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <span className="text-sm font-mono text-primary font-semibold">
              Lv.{hud.level}
            </span>
            <div className="flex items-center gap-1.5">
              <Scale className="size-3.5 text-primary" />
              <span className="text-xs font-mono text-foreground">
                {hud.alignment >= 0 ? '+' : ''}{hud.alignment} ({hud.alignmentLabel})
              </span>
            </div>
            <div className="flex items-center gap-1.5">
              <Star className="size-3.5 text-gold" />
              <span className="text-xs font-mono text-foreground">
                {hud.fame}
              </span>
            </div>
          </div>
          {hud.location && (
            <span className="text-xs font-mono text-muted-foreground">
              {hud.location}
            </span>
          )}
        </div>

        <div className="flex flex-col gap-1.5">
          <StatBar
            icon={Heart}
            label="HP"
            current={hud.hp}
            max={hud.maxHp}
            colorClass="text-hp"
          />
          <StatBar
            icon={Brain}
            label="SAN"
            current={hud.sanity}
            max={hud.maxSanity}
            colorClass="text-sanity"
          />
        </div>

        {hud.statusEffects.length > 0 && (
          <div className="flex items-center gap-2 flex-wrap">
            <Shield className="size-3.5 text-accent" />
            {hud.statusEffects.map((effect, i) => (
              <span key={i} className="text-xs px-1.5 py-0.5 bg-accent/20 text-accent-foreground rounded font-mono">
                {effect}
              </span>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
