'use client'

import { useState, useRef, useEffect, useCallback } from 'react'
import { useChat } from '@ai-sdk/react'
import { DefaultChatTransport } from 'ai'
import type { UIMessage } from 'ai'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Button } from '@/components/ui/button'
import { GameHUD } from '@/components/game-hud'
import { GameMessage } from '@/components/game-message'
import { GameSidebar } from '@/components/game-sidebar'
import { DiceRoller } from '@/components/dice-roller'
import { SaveLoadButtons } from '@/components/save-load-buttons'
import { parseGameStateFromMessage, parseHUDFromMessage } from '@/lib/parse-game-state'
import type { GameState } from '@/lib/game-types'
import { initialGameState } from '@/lib/game-types'
import {
  Send, PanelRightOpen, PanelRightClose,
  Dices, Loader2, AlertTriangle, RotateCcw,
} from 'lucide-react'

function getUIMessageText(msg: UIMessage): string {
  if (!msg.parts || !Array.isArray(msg.parts)) return ''
  return msg.parts
    .filter((p): p is { type: 'text'; text: string } => p.type === 'text')
    .map((p) => p.text)
    .join('')
}

const transport = new DefaultChatTransport({ api: '/api/chat' })

// ─────────────────────────────────────────────────────────────
// ChatEngine: key 가 바뀌면 remount → useChat 완전 리셋
// ─────────────────────────────────────────────────────────────
interface ChatEngineProps {
  seedMessages: UIMessage[]
  gameState: GameState
  setGameState: React.Dispatch<React.SetStateAction<GameState>>
  sidebarOpen: boolean
  setSidebarOpen: React.Dispatch<React.SetStateAction<boolean>>
  /** 불러오기 확정 시 TRPGGame 으로 전달 */
  onLoad: (loadedState: GameState, loadedMessages: UIMessage[]) => void
}

function ChatEngine({
  seedMessages,
  gameState,
  setGameState,
  sidebarOpen,
  setSidebarOpen,
  onLoad,
}: ChatEngineProps) {
  const [input, setInput] = useState('')
  const [showDice, setShowDice] = useState(false)
  const scrollRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLTextAreaElement>(null)

  // 로드된 메시지가 있으면 자동 시작 건너뜀
  const [gameStarted, setGameStarted] = useState(seedMessages.length > 0)

  const { messages, sendMessage, status, error } = useChat({
    transport,
    messages: seedMessages.length > 0 ? seedMessages : undefined,
    onError: (err) => console.log('[trpg] Chat error:', err.message),
  })

  const isLoading = status === 'streaming' || status === 'submitted'

  // 최신 assistant 메시지에서 GameState 추출
  useEffect(() => {
    const assistantMessages = messages.filter(m => m.role === 'assistant')
    if (assistantMessages.length === 0) return
    const text = getUIMessageText(assistantMessages[assistantMessages.length - 1])
    const parsed = parseGameStateFromMessage(text)
    if (parsed) {
      setGameState(prev => ({
        ...prev,
        ...parsed,
        character: parsed.character ?? prev.character,
        world: parsed.world ?? prev.world,
        quests: parsed.quests ?? prev.quests,
        npcs: parsed.npcs ?? prev.npcs,
        factions: parsed.factions ?? prev.factions,
        campaignProgress: parsed.campaignProgress ?? prev.campaignProgress,
        day: parsed.day ?? prev.day,
        timeOfDay: parsed.timeOfDay ?? prev.timeOfDay,
      }))
    }
  }, [messages, setGameState])

  // 최신 HUD 추출
  const latestHud = (() => {
    const assistantMessages = messages.filter(m => m.role === 'assistant')
    for (let i = assistantMessages.length - 1; i >= 0; i--) {
      const hud = parseHUDFromMessage(getUIMessageText(assistantMessages[i]))
      if (hud) return hud
    }
    return null
  })()

  // 자동 스크롤
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight
    }
  }, [messages, isLoading])

  // 새 게임 자동 시작 (seedMessages 없을 때만)
  useEffect(() => {
    if (messages.length === 0 && !gameStarted) {
      setGameStarted(true)
      sendMessage({ text: '게임을 시작합니다. Phase 0부터 시작해주세요.' })
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const handleRetry = useCallback(() => {
    sendMessage({ text: '게임을 시작합니다. Phase 0부터 시작해주세요.' })
  }, [sendMessage])

  const handleSubmit = useCallback(() => {
    if (!input.trim() || isLoading) return
    sendMessage({ text: input })
    setInput('')
    inputRef.current?.focus()
  }, [input, isLoading, sendMessage])

  const handleKeyDown = useCallback((e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSubmit()
    }
  }, [handleSubmit])

  return (
    <div className="flex h-screen bg-background">
      {/* ── Main Content ── */}
      <div className="flex-1 flex flex-col min-w-0">

        {/* Header */}
        <header className="shrink-0 border-b border-border bg-card/50 backdrop-blur-sm px-4 py-2 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Dices className="size-5 text-primary" />
            <h1 className="text-sm font-semibold text-foreground font-mono tracking-wide">
              TRPG CAMPAIGN ENGINE
            </h1>
            <span className="text-[10px] font-mono text-muted-foreground bg-secondary px-1.5 py-0.5 rounded">
              v2.5
            </span>
          </div>

          <div className="flex items-center gap-1">
            {/* 저장 / 불러오기 */}
            <SaveLoadButtons
              gameState={gameState}
              messages={messages}
              onLoad={onLoad}
              disabled={isLoading}
            />

            {/* 주사위 */}
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowDice(prev => !prev)}
              className="h-7 gap-1 text-xs"
            >
              <Dices className="size-3.5" />
              <span className="hidden sm:inline">주사위</span>
            </Button>

            {/* 사이드바 토글 */}
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setSidebarOpen(prev => !prev)}
              className="h-7"
            >
              {sidebarOpen
                ? <PanelRightClose className="size-4" />
                : <PanelRightOpen className="size-4" />}
            </Button>
          </div>
        </header>

        {/* HUD */}
        <GameHUD hud={latestHud} />

        {/* Dice Roller */}
        {showDice && (
          <div className="shrink-0 border-b border-border bg-card/30 px-4 py-2">
            <DiceRoller />
          </div>
        )}

        {/* Chat Area */}
        <div className="flex-1 overflow-hidden relative">
          <div ref={scrollRef} className="absolute inset-0 overflow-y-auto">
            <div className="max-w-3xl mx-auto">
              {messages.map((message) => (
                <GameMessage key={message.id} message={message} />
              ))}

              {isLoading && messages[messages.length - 1]?.role !== 'assistant' && (
                <div className="flex gap-3 py-4 px-4">
                  <div className="shrink-0 size-8 rounded-lg flex items-center justify-center bg-primary/20 text-primary">
                    <Loader2 className="size-4 animate-spin" />
                  </div>
                  <div className="flex-1">
                    <div className="text-xs font-mono text-muted-foreground mb-1">GM</div>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <span className="animate-pulse">주사위를 굴리는 중...</span>
                    </div>
                  </div>
                </div>
              )}

              {error && (
                <div className="mx-4 my-4 rounded-lg border border-destructive/50 bg-destructive/10 p-4">
                  <div className="flex items-start gap-3">
                    <AlertTriangle className="size-5 text-destructive shrink-0 mt-0.5" />
                    <div className="flex-1">
                      <p className="text-sm font-medium text-destructive">오류가 발생했습니다</p>
                      <p className="text-xs text-muted-foreground mt-1">
                        {error.message || 'AI GM과의 연결에 실패했습니다. 다시 시도해주세요.'}
                      </p>
                      <Button
                        variant="outline"
                        size="sm"
                        className="mt-3 h-7 gap-1.5 text-xs"
                        onClick={handleRetry}
                        disabled={isLoading}
                      >
                        <RotateCcw className="size-3" />
                        다시 시도
                      </Button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Input */}
        <div className="shrink-0 border-t border-border bg-card/50 backdrop-blur-sm p-3">
          <div className="max-w-3xl mx-auto">
            <div className="flex gap-2 items-end">
              <div className="flex-1 relative">
                <textarea
                  ref={inputRef}
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={handleKeyDown}
                  placeholder="행동을 입력하세요... (선택지 번호 또는 자유 행동)"
                  disabled={isLoading}
                  rows={1}
                  className="w-full resize-none rounded-lg border border-border bg-input px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring disabled:opacity-50 font-sans"
                  style={{ minHeight: '40px', maxHeight: '120px' }}
                  onInput={(e) => {
                    const target = e.target as HTMLTextAreaElement
                    target.style.height = 'auto'
                    target.style.height = Math.min(target.scrollHeight, 120) + 'px'
                  }}
                />
              </div>
              <Button
                onClick={handleSubmit}
                disabled={!input.trim() || isLoading}
                size="sm"
                className="h-10 px-3"
              >
                {isLoading
                  ? <Loader2 className="size-4 animate-spin" />
                  : <Send className="size-4" />}
              </Button>
            </div>
            <div className="flex items-center gap-3 mt-1.5 px-1">
              <span className="text-[10px] text-muted-foreground">Shift+Enter로 줄바꿈</span>
              <span className="text-[10px] text-muted-foreground">|</span>
              <span className="text-[10px] text-muted-foreground">
                숫자를 입력해 선택지를 고르거나, 자유롭게 행동을 서술하세요
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* ── Sidebar ── */}
      {sidebarOpen && (
        <aside className="w-72 lg:w-80 shrink-0 border-l border-border bg-card/30 hidden md:flex flex-col">
          <GameSidebar state={gameState} />
        </aside>
      )}
    </div>
  )
}

// ─────────────────────────────────────────────────────────────
// TRPGGame: 외부 래퍼 — chatKey 변경 시 ChatEngine remount
// ─────────────────────────────────────────────────────────────
export function TRPGGame() {
  const [chatKey, setChatKey]         = useState(0)
  const [seedMessages, setSeedMessages] = useState<UIMessage[]>([])
  const [gameState, setGameState]     = useState<GameState>(initialGameState)
  const [sidebarOpen, setSidebarOpen] = useState(true)

  /** 불러오기 확정 → 상태 교체 + ChatEngine remount */
  const handleLoad = useCallback((loadedState: GameState, loadedMessages: UIMessage[]) => {
    setGameState(loadedState)
    setSeedMessages(loadedMessages)
    setChatKey(k => k + 1)
  }, [])

  return (
    <ChatEngine
      key={chatKey}
      seedMessages={seedMessages}
      gameState={gameState}
      setGameState={setGameState}
      sidebarOpen={sidebarOpen}
      setSidebarOpen={setSidebarOpen}
      onLoad={handleLoad}
    />
  )
}
