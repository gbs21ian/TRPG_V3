'use client'

import { useState } from 'react'
import { Save, FolderOpen, Copy, Check, X, AlertTriangle } from 'lucide-react'
import { Button } from '@/components/ui/button'
import type { GameState } from '@/lib/game-types'
import type { UIMessage } from 'ai'
import { createSaveCode, loadFromCode, deserializeMessages } from '@/lib/save-system'

interface SaveLoadButtonsProps {
  gameState: GameState
  messages: UIMessage[]
  onLoad: (gameState: GameState, messages: UIMessage[]) => void
  disabled?: boolean
}

export function SaveLoadButtons({ gameState, messages, onLoad, disabled }: SaveLoadButtonsProps) {
  // 저장 모달
  const [showSaveModal, setShowSaveModal] = useState(false)
  const [saveCode, setSaveCode] = useState('')
  const [copied, setCopied] = useState(false)

  // 불러오기 모달
  const [showLoadModal, setShowLoadModal] = useState(false)
  const [loadInput, setLoadInput] = useState('')
  const [loadError, setLoadError] = useState('')

  /* ─── 저장 ─── */
  function handleSave() {
    const code = createSaveCode(gameState, messages)
    setSaveCode(code)
    setCopied(false)
    setShowSaveModal(true)
  }

  async function handleCopy() {
    try {
      await navigator.clipboard.writeText(saveCode)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    } catch {
      // fallback: select all
      const el = document.getElementById('save-code-textarea') as HTMLTextAreaElement | null
      el?.select()
    }
  }

  /* ─── 불러오기 ─── */
  function handleLoadOpen() {
    setLoadInput('')
    setLoadError('')
    setShowLoadModal(true)
  }

  function handleLoadConfirm() {
    if (!loadInput.trim()) {
      setLoadError('코드를 입력해주세요.')
      return
    }
    const data = loadFromCode(loadInput.trim())
    if (!data) {
      setLoadError('유효하지 않은 코드입니다. 코드를 다시 확인해주세요.')
      return
    }
    const restoredMessages = deserializeMessages(data.messages)
    onLoad(data.gameState, restoredMessages)
    setShowLoadModal(false)
    setLoadInput('')
    setLoadError('')
  }

  return (
    <>
      {/* 버튼 */}
      <Button
        variant="ghost"
        size="sm"
        onClick={handleSave}
        disabled={disabled || messages.length === 0}
        className="h-7 gap-1 text-xs"
        title="현재 진행 상황 저장"
      >
        <Save className="size-3.5" />
        <span className="hidden sm:inline">저장</span>
      </Button>
      <Button
        variant="ghost"
        size="sm"
        onClick={handleLoadOpen}
        disabled={disabled}
        className="h-7 gap-1 text-xs"
        title="저장 코드로 불러오기"
      >
        <FolderOpen className="size-3.5" />
        <span className="hidden sm:inline">불러오기</span>
      </Button>

      {/* ─── 저장 모달 ─── */}
      {showSaveModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center">
          {/* backdrop */}
          <div
            className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            onClick={() => setShowSaveModal(false)}
          />
          <div className="relative z-10 w-full max-w-lg mx-4 rounded-xl border border-border bg-card shadow-2xl">
            {/* 헤더 */}
            <div className="flex items-center justify-between p-4 border-b border-border">
              <div className="flex items-center gap-2">
                <Save className="size-4 text-primary" />
                <h2 className="text-sm font-semibold text-foreground font-mono">게임 저장</h2>
              </div>
              <button
                onClick={() => setShowSaveModal(false)}
                className="text-muted-foreground hover:text-foreground transition-colors"
              >
                <X className="size-4" />
              </button>
            </div>

            {/* 본문 */}
            <div className="p-4 flex flex-col gap-3">
              <p className="text-xs text-muted-foreground leading-relaxed">
                아래 코드를 복사해두세요. 나중에 <strong>불러오기</strong> 버튼을 눌러 이 코드를 입력하면
                현재 진행 상황에서 이어서 플레이할 수 있습니다.
              </p>
              <div className="relative">
                <textarea
                  id="save-code-textarea"
                  readOnly
                  value={saveCode}
                  rows={6}
                  className="w-full resize-none rounded-lg border border-border bg-secondary/30 px-3 py-2.5 text-[11px] font-mono text-foreground focus:outline-none focus:ring-2 focus:ring-ring leading-relaxed"
                />
              </div>
              <Button onClick={handleCopy} size="sm" className="w-full gap-2">
                {copied ? (
                  <>
                    <Check className="size-4 text-green-400" />
                    복사 완료!
                  </>
                ) : (
                  <>
                    <Copy className="size-4" />
                    코드 복사하기
                  </>
                )}
              </Button>
              <p className="text-[10px] text-muted-foreground text-center">
                저장 시각: {new Date().toLocaleString('ko-KR')}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* ─── 불러오기 모달 ─── */}
      {showLoadModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center">
          {/* backdrop */}
          <div
            className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            onClick={() => setShowLoadModal(false)}
          />
          <div className="relative z-10 w-full max-w-lg mx-4 rounded-xl border border-border bg-card shadow-2xl">
            {/* 헤더 */}
            <div className="flex items-center justify-between p-4 border-b border-border">
              <div className="flex items-center gap-2">
                <FolderOpen className="size-4 text-primary" />
                <h2 className="text-sm font-semibold text-foreground font-mono">게임 불러오기</h2>
              </div>
              <button
                onClick={() => setShowLoadModal(false)}
                className="text-muted-foreground hover:text-foreground transition-colors"
              >
                <X className="size-4" />
              </button>
            </div>

            {/* 본문 */}
            <div className="p-4 flex flex-col gap-3">
              <p className="text-xs text-muted-foreground leading-relaxed">
                저장 시 생성된 코드를 붙여넣으세요. <strong>현재 진행 중인 게임은 사라집니다.</strong>
              </p>
              <textarea
                value={loadInput}
                onChange={(e) => {
                  setLoadInput(e.target.value)
                  setLoadError('')
                }}
                placeholder="저장 코드를 여기에 붙여넣으세요..."
                rows={6}
                className="w-full resize-none rounded-lg border border-border bg-secondary/30 px-3 py-2.5 text-[11px] font-mono text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring leading-relaxed"
              />

              {loadError && (
                <div className="flex items-center gap-2 rounded-lg border border-destructive/50 bg-destructive/10 px-3 py-2">
                  <AlertTriangle className="size-3.5 text-destructive shrink-0" />
                  <span className="text-xs text-destructive">{loadError}</span>
                </div>
              )}

              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  className="flex-1"
                  onClick={() => setShowLoadModal(false)}
                >
                  취소
                </Button>
                <Button
                  size="sm"
                  className="flex-1 gap-2"
                  onClick={handleLoadConfirm}
                  disabled={!loadInput.trim()}
                >
                  <FolderOpen className="size-4" />
                  불러오기
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  )
}
