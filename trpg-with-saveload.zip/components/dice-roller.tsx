'use client'

import { useState, useCallback } from 'react'
import { Dices } from 'lucide-react'
import { Button } from '@/components/ui/button'

export function DiceRoller({ onRoll }: { onRoll?: (result: number, sides: number) => void }) {
  const [rolling, setRolling] = useState(false)
  const [result, setResult] = useState<number | null>(null)
  const [sides, setSides] = useState(20)

  const roll = useCallback(() => {
    setRolling(true)
    setResult(null)

    let count = 0
    const interval = setInterval(() => {
      setResult(Math.floor(Math.random() * sides) + 1)
      count++
      if (count > 10) {
        clearInterval(interval)
        const finalResult = Math.floor(Math.random() * sides) + 1
        setResult(finalResult)
        setRolling(false)
        onRoll?.(finalResult, sides)
      }
    }, 80)
  }, [sides, onRoll])

  const isCrit = result === sides
  const isFail = result === 1

  return (
    <div className="flex items-center gap-2">
      <div className="flex gap-1">
        {[4, 6, 8, 10, 12, 20].map(d => (
          <button
            key={d}
            onClick={() => setSides(d)}
            className={`text-[10px] font-mono px-1.5 py-0.5 rounded transition-colors ${
              sides === d ? 'bg-primary text-primary-foreground' : 'bg-secondary text-muted-foreground hover:text-foreground'
            }`}
          >
            d{d}
          </button>
        ))}
      </div>
      <Button
        size="sm"
        variant="outline"
        onClick={roll}
        disabled={rolling}
        className="h-7 gap-1 text-xs"
      >
        <Dices className={`size-3 ${rolling ? 'animate-spin' : ''}`} />
        {rolling ? '...' : '굴리기'}
      </Button>
      {result !== null && (
        <span className={`text-sm font-mono font-bold ${
          isCrit ? 'text-primary' : isFail ? 'text-destructive' : 'text-foreground'
        }`}>
          {result}
          {isCrit && ' !'}
          {isFail && ' ...'}
        </span>
      )}
    </div>
  )
}
