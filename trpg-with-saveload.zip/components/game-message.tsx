'use client'

import { Scroll, User, Dices } from 'lucide-react'
import { stripGameState, parseRollLog } from '@/lib/parse-game-state'
import type { UIMessage } from 'ai'

function getUIMessageText(msg: UIMessage): string {
  if (!msg.parts || !Array.isArray(msg.parts)) return ''
  return msg.parts
    .filter((p): p is { type: 'text'; text: string } => p.type === 'text')
    .map((p) => p.text)
    .join('')
}

function RollLogBlock({ rollLog }: { rollLog: string }) {
  const lines = rollLog.split('\n').filter(line => line.trim())
  return (
    <div className="my-3 border border-primary/30 bg-primary/5 rounded-lg p-3 font-mono text-xs">
      <div className="flex items-center gap-2 mb-2 text-primary font-semibold">
        <Dices className="size-4" />
        <span>ROLL LOG</span>
      </div>
      {lines.map((line, i) => {
        const [key, ...valueParts] = line.split(':')
        const value = valueParts.join(':').trim()
        if (!value) return <div key={i} className="text-muted-foreground">{line}</div>

        const isResult = key.trim() === '판정 결과'
        const isSuccess = value.includes('성공')
        const isCritical = value.includes('치명적')

        return (
          <div key={i} className="flex justify-between py-0.5">
            <span className="text-muted-foreground">{key.trim()}</span>
            <span
              className={
                isResult
                  ? isCritical && isSuccess
                    ? 'text-primary font-bold'
                    : isCritical
                      ? 'text-destructive font-bold'
                      : isSuccess
                        ? 'text-primary'
                        : 'text-destructive'
                  : 'text-foreground'
              }
            >
              {value}
            </span>
          </div>
        )
      })}
    </div>
  )
}

function formatNarrative(text: string): React.ReactNode[] {
  const cleaned = stripGameState(text)
  const withoutHud = cleaned.replace(/\[HUD\][\s\S]*?\[\/HUD\]/g, '').trim()
  const withoutRollLog = withoutHud.replace(/\[ROLL LOG\][\s\S]*?\[\/ROLL LOG\]/g, '__ROLLLOG__').trim()

  const rollLog = parseRollLog(text)

  const parts = withoutRollLog.split('__ROLLLOG__')
  const elements: React.ReactNode[] = []

  parts.forEach((part, i) => {
    if (i > 0 && rollLog) {
      elements.push(<RollLogBlock key={`roll-${i}`} rollLog={rollLog} />)
    }

    const lines = part.split('\n')
    lines.forEach((line, j) => {
      const trimmed = line.trim()
      if (!trimmed) {
        elements.push(<div key={`${i}-${j}`} className="h-2" />)
        return
      }

      if (trimmed.startsWith('━') || trimmed.startsWith('──') || trimmed.startsWith('┌') || trimmed.startsWith('└') || trimmed.startsWith('│')) {
        elements.push(
          <div key={`${i}-${j}`} className="font-mono text-xs text-primary/60 whitespace-pre">
            {trimmed}
          </div>
        )
        return
      }

      if (/^\d+\.\s/.test(trimmed)) {
        elements.push(
          <div key={`${i}-${j}`} className="py-0.5 pl-2 text-primary/90 hover:text-primary transition-colors cursor-default">
            {trimmed}
          </div>
        )
        return
      }

      if (trimmed.startsWith('[') && trimmed.endsWith(']')) {
        elements.push(
          <div key={`${i}-${j}`} className="text-sm font-semibold text-primary mt-2 mb-1">
            {trimmed}
          </div>
        )
        return
      }

      if (trimmed.startsWith('>')) {
        elements.push(
          <div key={`${i}-${j}`} className="border-l-2 border-primary/40 pl-3 text-muted-foreground italic text-sm py-0.5">
            {trimmed.slice(1).trim()}
          </div>
        )
        return
      }

      elements.push(
        <div key={`${i}-${j}`} className="leading-relaxed">
          {trimmed}
        </div>
      )
    })
  })

  return elements
}

export function GameMessage({ message }: { message: UIMessage }) {
  const text = getUIMessageText(message)
  const isGM = message.role === 'assistant'

  return (
    <div className={`flex gap-3 py-4 px-4 ${isGM ? '' : 'bg-secondary/30'}`}>
      <div className={`shrink-0 size-8 rounded-lg flex items-center justify-center ${
        isGM ? 'bg-primary/20 text-primary' : 'bg-secondary text-secondary-foreground'
      }`}>
        {isGM ? <Scroll className="size-4" /> : <User className="size-4" />}
      </div>
      <div className="flex-1 min-w-0">
        <div className="text-xs font-mono text-muted-foreground mb-1">
          {isGM ? 'GM' : 'Player'}
        </div>
        <div className="text-sm text-foreground">
          {isGM ? formatNarrative(text) : (
            <div className="whitespace-pre-wrap">{text}</div>
          )}
        </div>
      </div>
    </div>
  )
}
