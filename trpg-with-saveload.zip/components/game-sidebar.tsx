'use client'

import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { ScrollArea } from '@/components/ui/scroll-area'
import {
  Sword, Shield, Scroll, Users, Map, Package,
  Heart, Brain, Dices, Star, Swords, ChevronRight,
} from 'lucide-react'
import type { GameState } from '@/lib/game-types'
import { getStatModifier, getAlignmentLabel, LEVEL_EXP_TABLE } from '@/lib/game-types'

function StatRow({ label, value, modifier }: { label: string; value: number; modifier: number }) {
  return (
    <div className="flex items-center justify-between py-1 px-2 rounded hover:bg-secondary/50 transition-colors">
      <span className="text-xs text-muted-foreground">{label}</span>
      <div className="flex items-center gap-2">
        <span className="text-sm font-mono text-foreground">{value}</span>
        <span className={`text-xs font-mono ${modifier >= 0 ? 'text-primary' : 'text-destructive'}`}>
          ({modifier >= 0 ? '+' : ''}{modifier})
        </span>
      </div>
    </div>
  )
}

function CharacterPanel({ state }: { state: GameState }) {
  const char = state.character
  if (!char) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-muted-foreground text-sm py-12">
        <Shield className="size-8 mb-2 opacity-50" />
        <p>캐릭터 미생성</p>
      </div>
    )
  }

  const nextLevelExp = LEVEL_EXP_TABLE[char.level + 1] || 9999
  const expProgress = nextLevelExp > 0 ? ((char.exp - (LEVEL_EXP_TABLE[char.level] || 0)) / (nextLevelExp - (LEVEL_EXP_TABLE[char.level] || 0))) * 100 : 0

  return (
    <div className="flex flex-col gap-3 p-3">
      <div className="text-center border-b border-border pb-3">
        <h3 className="text-lg font-semibold text-foreground">{char.name || '???'}</h3>
        <div className="flex items-center justify-center gap-2 text-xs text-muted-foreground mt-1">
          <span>{char.race}</span>
          <span>|</span>
          <span>{char.class || '???'}</span>
        </div>
        <div className="flex items-center justify-center gap-1 mt-2">
          <span className="text-xs font-mono text-primary">Lv.{char.level}</span>
          <div className="w-20 h-1.5 bg-secondary rounded-full overflow-hidden ml-1">
            <div className="h-full bg-primary rounded-full transition-all" style={{ width: `${expProgress}%` }} />
          </div>
          <span className="text-[10px] font-mono text-muted-foreground">{char.exp}/{nextLevelExp}</span>
        </div>
      </div>

      <div className="flex flex-col gap-1.5">
        <div className="flex items-center gap-1.5 px-2">
          <Heart className="size-3 text-hp" />
          <span className="text-xs text-muted-foreground w-8">HP</span>
          <div className="flex-1 h-1.5 bg-secondary rounded-full overflow-hidden">
            <div className="h-full bg-hp rounded-full" style={{ width: `${(char.hp / char.maxHp) * 100}%` }} />
          </div>
          <span className="text-[10px] font-mono text-foreground">{char.hp}/{char.maxHp}</span>
        </div>
        <div className="flex items-center gap-1.5 px-2">
          <Brain className="size-3 text-sanity" />
          <span className="text-xs text-muted-foreground w-8">SAN</span>
          <div className="flex-1 h-1.5 bg-secondary rounded-full overflow-hidden">
            <div className="h-full bg-sanity rounded-full" style={{ width: `${(char.sanity / char.maxSanity) * 100}%` }} />
          </div>
          <span className="text-[10px] font-mono text-foreground">{char.sanity}/{char.maxSanity}</span>
        </div>
      </div>

      <div className="border-t border-border pt-2">
        <h4 className="text-xs font-semibold text-muted-foreground mb-1 px-2">STATS</h4>
        <StatRow label="근력 STR" value={char.stats.strength} modifier={getStatModifier(char.stats.strength)} />
        <StatRow label="민첩 AGI" value={char.stats.agility} modifier={getStatModifier(char.stats.agility)} />
        <StatRow label="지능 INT" value={char.stats.intelligence} modifier={getStatModifier(char.stats.intelligence)} />
        <StatRow label="카리스마 CHA" value={char.stats.charisma} modifier={getStatModifier(char.stats.charisma)} />
        <StatRow label="체력 END" value={char.stats.endurance} modifier={getStatModifier(char.stats.endurance)} />
        <StatRow label="운 LCK" value={char.stats.luck} modifier={getStatModifier(char.stats.luck)} />
      </div>

      <div className="border-t border-border pt-2 flex flex-col gap-1 px-2">
        <div className="flex justify-between text-xs">
          <span className="text-muted-foreground">정렬</span>
          <span className={`font-mono ${char.alignment >= 20 ? 'text-primary' : char.alignment <= -20 ? 'text-destructive' : 'text-foreground'}`}>
            {char.alignment >= 0 ? '+' : ''}{char.alignment} ({getAlignmentLabel(char.alignment)})
          </span>
        </div>
        <div className="flex justify-between text-xs">
          <span className="text-muted-foreground">명성</span>
          <span className="font-mono text-foreground">{char.fame}</span>
        </div>
        <div className="flex justify-between text-xs">
          <span className="text-muted-foreground">골드</span>
          <span className="font-mono text-gold">{char.gold}G</span>
        </div>
      </div>

      {char.skills.length > 0 && (
        <div className="border-t border-border pt-2">
          <h4 className="text-xs font-semibold text-muted-foreground mb-1 px-2">SKILLS</h4>
          {char.skills.map((skill, i) => (
            <div key={i} className="px-2 py-1.5 rounded hover:bg-secondary/50 transition-colors">
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium text-foreground">{skill.name}</span>
                <span className={`text-[10px] font-mono ${skill.currentCooldown > 0 ? 'text-destructive' : 'text-primary'}`}>
                  {skill.currentCooldown > 0 ? `CD: ${skill.currentCooldown}` : skill.type}
                </span>
              </div>
              <p className="text-[10px] text-muted-foreground mt-0.5 leading-relaxed">{skill.effect}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

function InventoryPanel({ state }: { state: GameState }) {
  const char = state.character
  if (!char) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-muted-foreground text-sm py-12">
        <Package className="size-8 mb-2 opacity-50" />
        <p>인벤토리 없음</p>
      </div>
    )
  }

  return (
    <div className="flex flex-col gap-3 p-3">
      <div>
        <h4 className="text-xs font-semibold text-muted-foreground mb-2">장비</h4>
        <div className="flex flex-col gap-1.5">
          {(['weapon', 'armor', 'accessory'] as const).map((slot) => {
            const item = char.equipment[slot]
            const slotLabels = { weapon: '무기', armor: '방어구', accessory: '장신구' }
            return (
              <div key={slot} className="flex items-center gap-2 px-2 py-1.5 rounded bg-secondary/30 border border-border">
                <Sword className="size-3 text-muted-foreground" />
                <span className="text-[10px] text-muted-foreground w-10">{slotLabels[slot]}</span>
                {item ? (
                  <div className="flex-1 flex items-center justify-between">
                    <span className="text-xs text-foreground">{item.name}</span>
                    <span className="text-[10px] font-mono text-primary">+{item.bonus}</span>
                  </div>
                ) : (
                  <span className="text-xs text-muted-foreground/50">--- 비어있음 ---</span>
                )}
              </div>
            )
          })}
        </div>
      </div>

      <div className="border-t border-border pt-2">
        <div className="flex items-center justify-between mb-2">
          <h4 className="text-xs font-semibold text-muted-foreground">아이템 ({char.inventory.length}/10)</h4>
          <span className="text-xs font-mono text-gold">{char.gold}G</span>
        </div>
        {char.inventory.length === 0 ? (
          <p className="text-xs text-muted-foreground/50 text-center py-4">아이템 없음</p>
        ) : (
          <div className="flex flex-col gap-1">
            {char.inventory.map((item, i) => (
              <div key={i} className="flex items-center justify-between px-2 py-1 rounded hover:bg-secondary/50">
                <span className="text-xs text-foreground">{item.name}</span>
                <span className="text-[10px] font-mono text-muted-foreground">x{item.quantity}</span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

function QuestPanel({ state }: { state: GameState }) {
  const activeQuests = state.quests.filter(q => q.status === 'active')
  const completedQuests = state.quests.filter(q => q.status === 'completed')

  return (
    <div className="flex flex-col gap-3 p-3">
      <div className="flex items-center justify-between">
        <h4 className="text-xs font-semibold text-muted-foreground">캠페인 진행도</h4>
        <span className="text-xs font-mono text-primary">{state.campaignProgress}%</span>
      </div>
      <div className="w-full h-2 bg-secondary rounded-full overflow-hidden">
        <div className="h-full bg-primary rounded-full transition-all" style={{ width: `${state.campaignProgress}%` }} />
      </div>

      <div className="flex items-center gap-2 text-xs text-muted-foreground">
        <Map className="size-3" />
        <span>Day {state.day}</span>
        <span>|</span>
        <span>{{ morning: '아침', afternoon: '오후', evening: '저녁', night: '밤' }[state.timeOfDay]}</span>
      </div>

      {activeQuests.length > 0 && (
        <div className="border-t border-border pt-2">
          <h4 className="text-xs font-semibold text-muted-foreground mb-1">진행 중</h4>
          {activeQuests.map((quest, i) => (
            <div key={i} className="px-2 py-1.5 rounded hover:bg-secondary/50 transition-colors">
              <div className="flex items-center gap-1.5">
                <ChevronRight className="size-3 text-primary" />
                <span className="text-xs font-medium text-foreground">{quest.name}</span>
                <span className="text-[10px] font-mono text-muted-foreground ml-auto">
                  {{ main: '메인', sub: '서브', hidden: '히든', personal: '개인' }[quest.type]}
                </span>
              </div>
              <p className="text-[10px] text-muted-foreground mt-0.5 pl-4.5 leading-relaxed">{quest.objective}</p>
            </div>
          ))}
        </div>
      )}

      {completedQuests.length > 0 && (
        <div className="border-t border-border pt-2">
          <h4 className="text-xs font-semibold text-muted-foreground mb-1">완료 ({completedQuests.length})</h4>
          {completedQuests.map((quest, i) => (
            <div key={i} className="px-2 py-0.5 text-xs text-muted-foreground/50 line-through">
              {quest.name}
            </div>
          ))}
        </div>
      )}

      {state.quests.length === 0 && (
        <div className="flex flex-col items-center justify-center text-muted-foreground text-sm py-8">
          <Scroll className="size-8 mb-2 opacity-50" />
          <p>퀘스트 없음</p>
        </div>
      )}
    </div>
  )
}

function RelationsPanel({ state }: { state: GameState }) {
  return (
    <div className="flex flex-col gap-3 p-3">
      {state.npcs.length > 0 && (
        <div>
          <h4 className="text-xs font-semibold text-muted-foreground mb-1">NPC 관계</h4>
          {state.npcs.map((npc, i) => (
            <div key={i} className="px-2 py-1.5 rounded hover:bg-secondary/50 transition-colors">
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium text-foreground">{npc.name}</span>
                <span className={`text-[10px] font-mono ${
                  npc.affinity >= 20 ? 'text-primary' :
                  npc.affinity <= -20 ? 'text-destructive' : 'text-muted-foreground'
                }`}>
                  {npc.affinity >= 0 ? '+' : ''}{npc.affinity}
                </span>
              </div>
              <div className="flex items-center gap-1 mt-0.5">
                <span className="text-[10px] text-muted-foreground">{npc.faction}</span>
                <span className="text-[10px] text-muted-foreground/50">|</span>
                <span className="text-[10px] text-muted-foreground">{npc.status}</span>
              </div>
            </div>
          ))}
        </div>
      )}

      {state.factions.length > 0 && (
        <div className="border-t border-border pt-2">
          <h4 className="text-xs font-semibold text-muted-foreground mb-1">세력 충성도</h4>
          {state.factions.map((faction, i) => (
            <div key={i} className="px-2 py-1.5 rounded hover:bg-secondary/50 transition-colors">
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium text-foreground">{faction.name}</span>
                <span className={`text-[10px] font-mono ${
                  faction.loyalty >= 20 ? 'text-primary' :
                  faction.loyalty <= -20 ? 'text-destructive' : 'text-muted-foreground'
                }`}>
                  {faction.loyalty >= 0 ? '+' : ''}{faction.loyalty} ({faction.status})
                </span>
              </div>
            </div>
          ))}
        </div>
      )}

      {state.npcs.length === 0 && state.factions.length === 0 && (
        <div className="flex flex-col items-center justify-center text-muted-foreground text-sm py-12">
          <Users className="size-8 mb-2 opacity-50" />
          <p>관계 없음</p>
        </div>
      )}
    </div>
  )
}

export function GameSidebar({ state }: { state: GameState }) {
  return (
    <Tabs defaultValue="character" className="flex flex-col h-full">
      <TabsList className="w-full rounded-none border-b border-border bg-card shrink-0">
        <TabsTrigger value="character" className="text-xs gap-1">
          <Shield className="size-3" />
          <span className="hidden lg:inline">캐릭터</span>
        </TabsTrigger>
        <TabsTrigger value="inventory" className="text-xs gap-1">
          <Package className="size-3" />
          <span className="hidden lg:inline">인벤토리</span>
        </TabsTrigger>
        <TabsTrigger value="quests" className="text-xs gap-1">
          <Scroll className="size-3" />
          <span className="hidden lg:inline">퀘스트</span>
        </TabsTrigger>
        <TabsTrigger value="relations" className="text-xs gap-1">
          <Users className="size-3" />
          <span className="hidden lg:inline">관계</span>
        </TabsTrigger>
      </TabsList>
      <ScrollArea className="flex-1">
        <TabsContent value="character" className="mt-0">
          <CharacterPanel state={state} />
        </TabsContent>
        <TabsContent value="inventory" className="mt-0">
          <InventoryPanel state={state} />
        </TabsContent>
        <TabsContent value="quests" className="mt-0">
          <QuestPanel state={state} />
        </TabsContent>
        <TabsContent value="relations" className="mt-0">
          <RelationsPanel state={state} />
        </TabsContent>
      </ScrollArea>
    </Tabs>
  )
}
